## Compare methods
######################
## Loading Packages ##
######################
library(foreach)
library(polycor)
library(psych)
library(ltm)
library(scrime)
library(sensitivity)
library(cluster)
library(stats)
library(mlogit)
library(missForest)


##################################
## point biserial and extension ##  
##################################
## x : continuous variable ##
## y : nominal variable    ##
biserial.cor2 <- function (x, y, use = c("all.obs", "complete.obs"), level = 2)
{
  if (!is.numeric(x))
    stop("'x' must be a numeric variable.\n")
  y <- as.factor(y)
  stopifnot(length(levs <- levels(y)) >= 2)
  if (length(x) != length(y))
    stop("'x' and 'y' do not have the same length")
  use <- match.arg(use)
  if (use == "complete.obs") {
    cc.ind <- complete.cases(x, y)
    x <- x[cc.ind]
    y <- y[cc.ind]
  }
  ## Point Biserial ##
  if (length(levs) == 2) { 
    ind <- y == levs[level]
    diff.mu <- mean(x[ind]) - mean(x[!ind])
    prob <- mean(ind)
    diff.mu * sqrt(prob * (1 - prob))/sd(x)
    ## Point Biserial Extension ##
  } else if (length(levs) > 2) { 
    n.m <- table(y)
    n <- sum(n.m)
    x.bar <- mean(x)
    x.bar.m <- sapply(split(x, y), mean)
    s.sqr <-  sum((x - x.bar)^2/n) #(n-1)/n*var(y)
    s.m <- n.m*(x.bar.m-x.bar)/n
    n*sum(s.m^2/(n.m*s.sqr))
  }
}
pcc2 <- function (x, dist = FALSE, corrected = TRUE, version = 1) 
{
  minrc <- function(x){
    rx<-max(x,na.rm=TRUE)
    n.lev<-numeric(nrow(x))
    for(i in min(x,na.rm=TRUE):rx){
      tmp<-x==i
      tmp2<-rowSums(tmp,na.rm=TRUE)>0
      n.lev<-n.lev+tmp2
    }
    uni.lev<-sort(unique(n.lev),decreasing=TRUE)
    #if(uni.lev[1]!=rx)
    #        stop("No variable shows all possible levels.",call.=FALSE)
    if(length(uni.lev)==1)
      return(uni.lev)
    mat.rc<-matrix(rx,nrow(x),nrow(x))
    for(i in uni.lev[-1]){
      ids<-which(n.lev==i)
      mat.rc[ids,]<-i
      mat.rc[,ids]<-i
    }
    mat.rc
  }
  #if (!version %in% (1:3)) 
  #stop("version must be between 1 and 3.")
  if (dist & !corrected) 
    stop("corrected must be TRUE, if dist = TRUE.")
  chi2 <- scrime::rowChisqStats(x, compPval = FALSE)
  chi2 <- chi2 + t(chi2)
  if (any(is.na(x))) {
    naIdentifier <- !is.na(x)
    mat.n <- naIdentifier %*% t(naIdentifier)
  }
  else mat.n <- ncol(x)
  pcc <- chi2/(chi2 + mat.n)
  mat.rc <- minrc(x)
  mat.rc <- mat.rc/(mat.rc - 1)
  #print(mat.rc)
  #print(diag(pcc))
  diag(pcc) <- if (is.matrix(mat.rc)) 
    1/diag(mat.rc)
  else 1/mat.rc
  if (corrected) 
    pcc <- mat.rc * pcc
  colnames(pcc) <- rownames(pcc) <- rownames(x)
  if (!dist) {
    pcc <- sqrt(pcc)
    return(pcc)
  }
  pcc <- switch(version, sqrt(1 - pcc), 1 - sqrt(pcc), 1 - pcc)
  pcc
}

##############################################
## Function to establish Correlation Matrix ##                 
##############################################
calCor <- function(dat, types) {
  stopifnot(length(types)==2)
  
  if("con" %in% types) {
    if(all(types=="con")) {  ## con vs con: spearman's R
      res <- cor(as.numeric(dat[,1]), as.numeric(dat[,2]), use="pairwise.complete.obs",method="spearman")
    } else if("ord" %in% types) { ## con vs ord: polyserial
      dat <- na.omit(dat)
      ord.idx <- which(types=="ord")
      level <- nlevels(as.factor(dat[,ord.idx]))-(max(dat[,ord.idx])-min(dat[,ord.idx])+1)
      value <- nlevels(as.factor(dat[,ord.idx]))
      res <- NA
      if((level != 0)|(value<3)|(length(unique(dat[,setdiff(1:ncol(dat),ord.idx)]))<3)){res <- NA}
      else{
        res <- polycor::polyserial(as.numeric(dat[,setdiff(1:ncol(dat),ord.idx)]),as.numeric(dat[,ord.idx])) #polyserial
        if(abs(res)==1){
          n1 <- ord.idx
          ord <- as.factor(dat[,n1])
          dat[,n1] <- dat[,n1] - min(dat[,n1]) + 1
          dat.2 <- dat[,n1]
          n_old <- 0
          n <- vector(length=nlevels(ord))
          s <- min(dat[,n1])
          for (i in s:(nlevels(ord)+s-1)){
            no <- which(dat.2==i)
            n[i+1-s] <- length(no)
            new.level.1 <- 0.5*(1+n_old+n[i+1-s]+n_old)
            n_old <- sum(n[1:(i+1-s)])  
            dat[no,n1] <- new.level.1
          }    
          res <- cor(as.numeric(dat[,1]), as.numeric(dat[,2]), use="pairwise.complete.obs",method="pearson")}}
    } else if("nom" %in% types) { ## con vs nom: point biserial and extension
      dat <- na.omit(dat)
      level <- nlevels(as.factor(dat[,which(types%in%c("nom"))]))-(max(dat[,which(types%in%c("nom"))])-min(dat[,which(types%in%c("nom"))])+1)
      value <- nlevels(as.factor(dat[,which(types%in%c("nom"))]))
      if((level != 0)|(value<2)|(length(which(dat[,which(types%in%c("nom"))]==1))<2)|(length(unique(dat[,which(types%in%c("con"))]))<3)){res <- NA}
      else{
        nom.idx <- which(types=="nom")
        res <- biserial.cor2(as.numeric(dat[,setdiff(1:ncol(dat),nom.idx)]),as.numeric(dat[,nom.idx]), use="complete.obs") #biserial or multivariate
      } }}
  else if("ord" %in% types) {
    if(all(types=="ord")) { ## ord vs ord: polychoric correlation and pearson's r 
      dat <- na.omit(dat)  
      n1 <- as.factor(dat[,1])
      n2 <- as.factor(dat[,2])
      level.1 <- nlevels(n1)-(max(dat[,1])-min(dat[,1])+1)
      value.1 <- nlevels(n1)  
      level.2 <- nlevels(n2)-(max(dat[,2])-min(dat[,2])+1)
      value.2 <- nlevels(n2)
      if((level.2 != 0)|(value.2<3)|(level.1 != 0)|(value.1<3)){res <- NA}
      else if(min(table(dat[,1],dat[,2]))<3) {
        n_old <- 0
        n <- vector(length=nlevels(n2))
        s <- min(dat[,2])
        for (i in s:(nlevels(n2)+s-1)){
          no <- which(dat[,2]==i)
          n[i+1-s] <- length(no)
          new.level.2 <- 0.5*(1+n_old+n[i+1-s]+n_old)
          n_old <- sum(n[i+1-s:i])  
          dat[no,2] <- rep(new.level.2,length(no))
        }
        res <- cor(as.numeric(dat[,1]), as.numeric(dat[,2]), use="pairwise.complete.obs",method="pearson")}
      else{
        res <- polychor(dat[,1],dat[,2])
      }
    }
    else if("nom" %in% types) { #ord vs nom:rank biserial: point biserial and extension
      dat <- na.omit(dat)
      n1 <- as.factor(dat[,1])
      n2 <- as.factor(dat[,2])
      ord.idx <- which(types=="ord")
      nom.idx <- which(types=="nom")
      level.1 <- nlevels(as.factor(dat[,ord.idx]))-(max(dat[,ord.idx])-min(dat[,ord.idx])+1)
      value.1 <- nlevels(as.factor(dat[,ord.idx]))  
      level.2 <- nlevels(as.factor(dat[,nom.idx]))-(max(dat[,nom.idx])-min(dat[,nom.idx])+1)
      value.2 <- nlevels(as.factor(dat[,nom.idx]))
      if((level.2 != 0)|(value.1<3)|(level.1 != 0)|(value.2<2)|(length(which(dat[,which(types%in%c("nom"))]==1))<2)){res <- NA}
      else{
        n1 <- ord.idx
        ord <- as.factor(dat[,n1])
        dat[,n1] <- dat[,n1] - min(dat[,n1]) + 1
        dat.2 <- dat[,n1]
        n_old <- 0
        n <- vector(length=nlevels(ord))
        s <- min(dat[,n1])
        for (i in s:(nlevels(ord)+s-1)){
          no <- which(dat.2==i)
          n[i+1-s] <- length(no)
          new.level.1 <- 0.5*(1+n_old+n[i+1-s]+n_old)
          n_old <- sum(n[1:(i+1-s)])  
          dat[no,n1] <- new.level.1
        }
        dat[,1] <- factor(dat[,1]); dat[,2] <- factor(dat[,2])
        res <- biserial.cor2(as.numeric(dat[,setdiff(1:ncol(dat),ord.idx)]), dat[,ord.idx],use="complete.obs")} 
      #biserial or multivariat
    }
  }   
  else { ## nom vs nom: phi pearson's C and cramer's V
    stopifnot(all(types=="nom"))
    dat <- na.omit(dat)
    n1 <- as.factor(dat[,1]); n2 <- as.factor(dat[,2])
    level.1 <- nlevels(as.factor(dat[,1]))-(max(dat[,1])-min(dat[,1])+1)
    value.1 <- nlevels(as.factor(dat[,1]))  
    level.2 <- nlevels(as.factor(dat[,2]))-(max(dat[,2])-min(dat[,2])+1)
    value.2 <- nlevels(as.factor(dat[,2]))
    if((level.2 != 0)|(value.2<2)|(level.1 != 0)|(value.1<2)|(length(which(dat[,1]==1))<2)|(length(which(dat[,2]==1))<2)){res <- NA}
    else{
      if((nlevels(n1)==2 & nlevels(n2)==2)== TRUE) {
        dat <- as.data.frame(dat)
        res <- psych::phi(table(dat), digits=5)
      } 
      else if(nlevels(n1)!=nlevels(n2)){
        L <- min(nlevels(n1),nlevels(n2))
        dat[,1] <- dat[,1] - min(dat[,1]) + 1
        dat[,2] <- dat[,2] - min(dat[,2]) + 1
        chi.s <- scrime::rowChisqStats(t(as.matrix(dat)),compPval = FALSE)
        chi.s <- chi.s +t(chi.s)
        res <- (chi.s[2,1]/(nrow(dat)*ncol(dat)*(L-1)))^0.5}
      else 
      {dat <- as.data.frame(dat)
       res <- pcc2(t(dat))[2,1]
      }}
  }
  res
}

###################################
## Calculate the Distance matrix ##
###################################
mixedDist <- function(dat, types) {
  stopifnot(levels(factor(types))%in%c("con","ord","nom"))
  stopifnot(ncol(dat)==length(types))
  dist <- matrix(0,ncol(dat),ncol(dat))
  pairwise.cor = lapply(as.list(c(1:(ncol(dat)-1))),function(x) sapply(c((x+1):ncol(dat)),function(y) calCor(dat[,c(x,y)], types[c(x,y)])))
  for (i in 1:(ncol(dat)-1)) {
    dist[i,(i+1):ncol(dat)] = 1 - abs(pairwise.cor[[i]])
  }
  dist <- dist + t(dist)
  return(dist)
}

########################################
####### Generate missing value #########
########################################
## revise this function on 4/23/2013
missing.no <- function(data,n,perc){
  missing.data <- vector("list",length=n)
  m <- ncol(data)*nrow(data)
  set.seed(23456)   ## use this seed
  missing.data = lapply(1:n,function(x) sample(1:m,round(m*perc)))
  return(missing.data)
}

#################################################
####### Generate secondary missing value #########
#################################################
## revise this function on 4/23/2013

missing.no.2 <- function(data,n,perc,missing.1){
  missing.data <- vector("list",length=n)
  m <- ncol(data)*nrow(data)
  m.2 <- c(1:m)[-missing.1]
  total <- length(m.2)
  set.seed(12345)   ## use this seed
  missing.data = lapply(1:n,function(x) sample(m.2,round(total*perc)))
  return(missing.data)
}

missing.no.3 <- function(data,n,perc,missing.1,missing.2){
  missing.data <- vector("list",length=n)
  m <- ncol(data)*nrow(data)
  m.2 <- c(1:m)[-c(missing.1,missing.2)]
  total <- length(m.2)
  set.seed(12345)   ## use this seed
  missing.data = lapply(1:n,function(x) sample(m.2,round(total*perc)))
  return(missing.data)
}
#############################################
## Get final weighted imputed value: KNN.v ##
#############################################
## revise this function on 4/23/2013
determin.i <- function(k.imputed,weight,miss.type,w){
  ## weight could be adjusted according to user's preference
  if (miss.type%in%"con"){imputed.value <- weighted.mean(k.imputed,weight^w)}
  else if(miss.type%in%"nom"){ 
    p.number <- length(table(k.imputed))
    weight.sum <- tapply(weight,k.imputed,sum)
    if (length(max(weight.sum))>1){imputed.value <- sample(as.numeric(names(which.max(weight.sum))),1)}
    else{imputed.value <- as.numeric(names(which.max(weight.sum)))}
  } 
  else {imputed.value <- round(weighted.mean(k.imputed,weight^w))}
  #if(length(imputed.value)>1){imputed.value <- sample(imputed.value,1)}
  return(imputed.value)  
}

#############################
## Evaluate the imputation ##
#############################
## revise this function on 4/23/2013
Evaluate <- function(imputed.value,true.value,miss.type,col,Complete){
  if (miss.type=="con"){
    ## normalized square error
    ## could be >1
    accu.v <-((true.value-imputed.value)/sd(na.omit(Complete[,col])))^2
  }
  else if (miss.type=="nom"){
    ## 0~1
    if(true.value==imputed.value){accu.v <- 0}
    else {accu.v <- 1}
  }
  else {
    ## 0~1
    min.value = min(na.omit(Complete[,col]))
    max.value = max(na.omit(Complete[,col]))
    accu.v <- ((true.value-max(min.value,min(round(imputed.value),max.value)))/(nlevels(as.factor(Complete[,col]))-1))^2}
  accu.v  
}

#################################
## Function of Mean Imputation ##
#################################
## revise this function on 4/23/2013
each.mv.m.i <- function(col,mv.comp,Type){
  dat <- as.numeric(na.omit(mv.comp[,col]))
  if (Type[col]=="con"){imputed.m.i <- mean(dat)}
  else if (Type[col]=="nom"){
    imputed.m.i <- as.numeric(names(which.max(table(dat))))}
  else {imputed.m.i <- round(mean(dat))
        if(imputed.m.i>max(dat)){imputed.m.i=max(imputed.m.i)}}
  return(imputed.m.i)  
}


##################################################################################################################
####### Function Get imputed value(single missing single neighbor if there is a neighbor) KNN.v####
##################################################################################################################
Imp.Single <- function(neighbor.all,regression.all,miss.col,miss.row,neighbor.col,Type,mv.data){
  
  coeff.neighbor <- which(neighbor.all==neighbor.col)  ## the regression coefficient corresponding to each neighbor
  coeff <- regression.all[[coeff.neighbor]]
  ## Each pair of missing value and neighbor
  dat <- mv.data[,c(miss.col,neighbor.col)]
  depend <- dat[miss.row,2]
  dat <- na.omit(dat)
  min.1 <- min(dat[,1])
  max.1 <- max(dat[,1])
  min.2 <- min(dat[,2])
  max.2 <- max(dat[,2])
  level.1 <- nlevels(as.factor(dat[,1]))
  level.2 <- nlevels(as.factor(dat[,2]))
  type <- c(Type[c(miss.col,neighbor.col)]) ## variable type for missing value and neighbor
  if(sum(type==c("con","con"))==2){
    imp <- coeff[1]+coeff[2]*depend
  }
  if(sum(type==c("con","nom"))==2){
    possible <- sort(unique(dat[,2]))
    if(depend%in%possible==FALSE){depend <- sample(as.numeric(row.names(table(dat[,2]))),1,prob=table(dat[,2])/sum(table(dat[,2])))}
    no <- which(possible==depend)
    if(no==1){imp <- coeff[1]}
    else{
      imp <- coeff[1] + coeff[no] * 1}
  }
  if(sum(type==c("con","ord"))==2){
    imp <- coeff[1]+coeff[2]*depend
  }
  if(sum(type==c("ord","con"))==2){
    #depend <- depend - mean(dat[,2])  
    ## if Sparse cell when high missing,we cannot regress. Use other methods to impute in this case #
    if(unique(is.na(coeff))==TRUE){obs <- which(abs(depend-dat[,2])==min(abs(depend-dat[,2]))) ## similiar to KNN.s
                                   imp <- dat[obs,1]}
    else{
      cut <- coeff[[2]]
      predictor <- coeff[[1]]
      p.value <- vector(length=level.1)
      p.value[1] <- 1/(1+exp(-(cut[1]-predictor*depend))) 
      for (i in 2:(level.1-1)){
        p.value[i] <- 1/(1+exp(-(cut[i]-predictor*depend))) - 1/(1+exp(-(cut[i-1]-predictor*depend)))
      }
      p.value[level.1] <- 1 - 1/(1+exp(-(cut[i]-predictor*depend)))
      possible.value <- c(min.1:(min.1+level.1-1))
      imp <- max(possible.value[p.value==max(p.value)])
    }  
  }
  if(sum(type==c("ord","ord"))==2){
    possible <- sort(unique(dat[,2]))
    if(min(table(dat[,1],dat[,2]))<10){ ## if sparse cell use conditional probability(use contingency table)
      if(depend%in%possible==FALSE){depend <- sample(as.numeric(row.names(table(dat[,2]))),1,prob=table(dat[,2])/sum(table(dat[,2])))}
      table <- table(dat[,1],dat[,2])
      if(depend - min.2 + 1>ncol(table)){depend <- ncol(table)}
      else{miss.dist <- table[,depend - min.2 + 1]}
      name <- as.numeric(names(miss.dist[which(miss.dist>0)]))
      prob <- miss.dist[which(miss.dist>0)]/sum(miss.dist)   
      if(length(name)==1){imp <- name}
      else{imp <- max(name[which(prob==max(prob))])}} ## similiar to mean imputation    
    else{
      cut <- coeff[[2]]
      predictor <- coeff[[1]]
      p.value <- vector(length=level.1)
      p.value[1] <- 1/(1+exp(-(cut[1]-predictor*depend))) 
      for (i in 2:(level.1-1)){
        p.value[i] <- 1/(1+exp(-(cut[i]-predictor*depend))) - 1/(1+exp(-(cut[i-1]-predictor*depend)))
      }
      p.value[level.1] <- 1 - 1/(1+exp(-(cut[i]-predictor*depend)))
      possible.value <- c(min.1:(min.1+level.1-1))
      imp <- max(possible.value[p.value==max(p.value)])
    }}
  if(sum(type==c("ord","nom"))==2){
    if(min(table(dat[,1],dat[,2]))<10){ ## if sparse cell use conditional probability(use contingency table)
      table <- table(dat[,1],dat[,2])
      possible <- sort(unique(dat[,2]))
      if(depend%in%possible==FALSE){depend <- sample(as.numeric(row.names(table(dat[,2]))),1,prob=table(dat[,2])/sum(table(dat[,2])))}
      no <- which(possible==depend)
      miss.dist <- table[,no]
      name <- as.numeric(names(miss.dist[which(miss.dist>0)]))
      prob <- miss.dist[which(miss.dist>0)]/sum(miss.dist)
      if(length(name)==1){imp <- name}
      else{imp <- max(name[prob==max(prob)])}
    }
    else{
      cut <- coeff[[2]]
      predictor <- coeff[[1]]
      possible <- sort(unique(dat[,2]))
      no <- which(possible==depend)
      if(depend == possible[1]){predictor.use <- 0}
      else{predictor.use <- predictor[no]}
      p.value <- vector(length=length(possible))
      p.value[1] <- 1/(1+exp(-(cut[1]-predictor.use))) 
      for (i in 2:(level.1-1)){
        p.value[i] <- 1/(1+exp(-(cut[i]-predictor.use))) - 1/(1+exp(-(cut[i-1]-predictor.use)))
      }
      p.value[level.1] <- 1 - 1/(1+exp(-(cut[i]-predictor.use)))
      imp <- max(possible[p.value==max(p.value)])    	
    }
  }
  if(sum(type==c("nom","con"))==2){ 
    if(level.1==2){ ##logistic regression
      if(min(table(dat[,1]))<10){imp <- sample(as.numeric(row.names(table(dat[,1]))),1,prob=table(dat[,1])/sum(table(dat[,1])))}
      else{ 
        p.i <- exp(coeff[1]+coeff[2]*depend)/(1+exp(coeff[1]+coeff[2]*depend))
        if(is.na(p.i)==TRUE){p.i <- 1}
        if(p.i > 0.5){imp <- max.1} ## P(outcome=1) > P(outcome=0)
        else {imp <- min.1}}}
    else if(level.1 > 2) { ##multinomial logistic regression
      if(min(table(dat[,1]))<10){imp <- sample(as.numeric(row.names(table(dat[,1]))),1,prob=table(dat[,1])/sum(table(dat[,1])))}
      else{
        logit <- vector(length=nlevels(as.factor(dat[,1]))-1) 
        for (i in 1:(nlevels(as.factor(dat[,1]))-1)){
          logit[i] <- coeff[i] + depend * coeff[i+level.1-1]
        }
        exp.beta <- exp(logit)
        p <- vector(length=nlevels(as.factor(dat[,1])))
        p[1] <- 1/(1+sum(exp.beta))
        for (i in 2:nlevels(as.factor(dat[,1]))){
          p[i] <- exp.beta[i-1]/(1+sum(exp.beta))}
        value <- c(min.1:max.1)
        imp <- max(value[p==max(p)])}
    }
  }
  if(sum(type==c("nom","ord"))==2){
    if(level.1==2){
      if(min(table(dat[,1],dat[,2]))<10){table <- table(dat[,1],dat[,2])
                                         possible <- sort(unique(dat[,2]))
                                         if(depend%in%possible==FALSE){depend <- sample(as.numeric(row.names(table(dat[,2]))),1,prob=table(dat[,2])/sum(table(dat[,2])))}     
                                         no <- which(possible==depend)
                                         miss.dist <- table[,no]   
                                         name <- as.numeric(names(miss.dist[miss.dist>0]))
                                         prob <- miss.dist[miss.dist>0]/sum(miss.dist)
                                         if(length(name)==1){imp <- name}
                                         else{imp <- max(name[prob==max(prob)])}
      }
      else{
        possible <- sort(unique(dat[,2]))
        if(depend%in%possible==FALSE){depend <- sample(as.numeric(row.names(table(dat[,2]))),1,prob=table(dat[,2])/sum(table(dat[,2])))}     
        if(depend==min.2){p.i <- exp(coeff[1])/(1+exp(coeff[1]))}
        else{p.i <- exp(coeff[1]+coeff[depend-min.2+1]*1)/(1+exp(coeff[1]+coeff[depend-min.2+1]*1))}	
        if(is.na(p.i)==TRUE){p.i <- 1}
        if(p.i > 0.5){imp <- max.1} ## P(outcome=1) > P(outcome=0)
        else {imp <- min.1}
      }
    }
    else if(level.1 > 2) { ##multinomial logistic regression
      if(min(table(dat[,1],dat[,2]))<10){table <- table(dat[,1],dat[,2])
                                         possible <- sort(unique(dat[,2]))
                                         if(depend%in%possible==FALSE){depend <- sample(as.numeric(row.names(table(dat[,2]))),1,prob=table(dat[,2])/sum(table(dat[,2])))}     
                                         no <- which(possible==depend)
                                         miss.dist <- table[,no]   
                                         name <- as.numeric(names(miss.dist[miss.dist>0]))
                                         prob <- miss.dist[miss.dist>0]/sum(miss.dist)
                                         if(length(name)==1){imp <- name}
                                         else{imp <- max(name[prob==max(prob)])}
      }
      else{
        logit <- vector(length=nlevels(as.factor(dat[,1]))-1) ##CALCULATE BETA
        for (i in 1:(nlevels(as.factor(dat[,1]))-1)){
          logit[i] <- coeff[i] + depend * coeff[i+level.1-1]
        }
        exp.beta <- exp(logit)
        p <- vector(length=nlevels(as.factor(dat[,1])))
        p[1] <- 1/(1+sum(exp.beta))
        for (i in 2:nlevels(as.factor(dat[,1]))){
          p[i] <- exp.beta[i-1]/(1+sum(exp.beta))}
        value <- c(min.1:max.1)
        imp <- max(value[p==max(p)])}
    }
  }
  if(sum(type==c("nom","nom"))==2){
    if(level.1==2){ ##logistic regression
      if(min(table(dat[,1],dat[,2]))<10){table <- table(dat[,1],dat[,2])
                                         possible <- sort(unique(dat[,2]))
                                         if(depend%in%possible==FALSE){depend <- sample(as.numeric(row.names(table(dat[,2]))),1,prob=table(dat[,2])/sum(table(dat[,2])))}     
                                         no <- which(possible==depend)
                                         miss.dist <- table[,no]   
                                         name <- as.numeric(names(miss.dist[miss.dist>0]))
                                         prob <- miss.dist[miss.dist>0]/sum(miss.dist)
                                         if(length(name)==1){imp <- name}
                                         else{imp <- max(name[prob==max(prob)])}
      }
      else{        
        possible <- sort(unique(dat[,2]))
        if(depend%in%possible==FALSE){depend <- sample(as.numeric(row.names(table(dat[,2]))),1,prob=table(dat[,2])/sum(table(dat[,2])))}     
        no <- which(possible==depend)
        if(depend>min.2){p.i <- exp(coeff[1]+coeff[no])/(1+exp(coeff[1]+coeff[no]))}	
        else{p.i <- exp(coeff[1])/(1+exp(coeff[1]))}
        if(is.na(p.i)==TRUE){p.i <- 1}
        if(p.i > 0.5){imp <- max.1} ## P(outcome=1) > P(outcome=0)
        else {imp <- min.1}
      }
    }
    else if(level.1 > 2) { ##multinomial logistic regression
      if(min(table(dat[,1],dat[,2]))<10){table <- table(dat[,1],dat[,2])
                                         possible <- sort(unique(dat[,2]))
                                         if(depend%in%possible==FALSE){depend <- sample(as.numeric(row.names(table(dat[,2]))),1,prob=table(dat[,2])/sum(table(dat[,2])))}     
                                         no <- which(possible==depend)
                                         miss.dist <- table[,no]   
                                         name <- as.numeric(names(miss.dist[miss.dist>0]))
                                         prob <- miss.dist[miss.dist>0]/sum(miss.dist)
                                         if(length(name)==1){imp <- name}
                                         else{imp <- max(name[prob==max(prob)])}
      }
      else{
        possible <- sort(unique(dat[,2]))
        if(depend%in%possible==FALSE){depend <- sample(as.numeric(row.names(table(dat[,2]))),1,prob=table(dat[,2])/sum(table(dat[,2])))}     
        no <- which(possible==depend)
        logit <- vector(length=nlevels(as.factor(dat[,1]))-1) 
        for (i in 1:(nlevels(as.factor(dat[,1]))-1)){
          if(no==1) logit[i]<-coeff[i]
          else logit[i] <- coeff[i] + coeff[(no-1)*(level.1-1)+i]
        }
        exp.beta <- exp(logit)
        p <- vector(length=nlevels(as.factor(dat[,1])))
        p[1] <- 1/(1+sum(exp.beta))
        for (i in 2:nlevels(as.factor(dat[,1]))){
          p[i] <- exp.beta[i-1]/(1+sum(exp.beta))}
        value <- c(min.1:max.1)
        imp <- max(value[p==max(p)])}
    }
  }
  if(length(imp)>1){imp <- sample(imp,1)}
  imp
}
##############################################
####  Get coefficient for each possible reg ##
##############################################
cal.reg.coef <- function(mv.data,miss.col,neighbor.col,Type){
  dat <- na.omit(mv.data[,c(miss.col,neighbor.col)])
  table <- table(dat[,1],dat[,2])
  m.type <- Type[miss.col]
  n.type <- Type[neighbor.col]
  if("con" %in% m.type){ ## linear regression
    if("con" %in% n.type){
      coeff <- as.vector(lm(dat[,1]~dat[,2])$coefficients) 
    } else if("ord" %in% n.type) ## treat ordinal variable as continuous
    {coeff <- as.vector(lm(dat[,1]~dat[,2])$coefficients)
    } else if("nom" %in% n.type)
    {min <- min(dat[,2],na.rm=TRUE)
     max <- max(dat[,2],na.rm=TRUE)
     dat=data.frame(dat)
     dat[,2] <- factor(dat[,2])  ## Create dummy variables
     coeff <- as.vector(lm(dat[,1]~dat[,2])$coefficients)    
    }}
  else if("ord" %in% m.type){ ## ordinal logistic regression
    min.1 <- min(dat[,1])
    max.1 <- max(dat[,1])
    min.2 <- min(dat[,2])
    max.2 <- max(dat[,2])
    level.1 <- nlevels(as.factor(dat[,1]))
    level.2 <- nlevels(as.factor(dat[,2]))
    table <- table(dat[,1],dat[,2])
    if("con" %in% n.type){ ## beta are all same, intercept different
      if((min(table(dat[,1]))<10)|(level.1-(max.1-min.1+1)!=0)){coeff <- NA}
      else{
        #dat[,2] <- dat[,2] - mean(dat[,2])
        t <- try(polr(as.ordered(dat[,1])~dat[,2],data=dat),T)
        if(is.character(t[[1]])!=TRUE){         
          polr.out <- polr(as.ordered(dat[,1])~dat[,2],data=dat)
          predictor <- polr.out$coefficients
          cut <- polr.out$zeta
          coeff <- list(predictor,cut)}
        else{coeff <- NA}}  ## this is a list
    } else if("ord" %in% n.type){  ## ordinal logistic regression or linear regression
      if(min(table)<10){coeff <- NA}
      else{
        polr.out <- polr(as.ordered(dat[,1])~dat[,2],data=dat)
        predictor <- polr.out$coefficients
        min <- min(dat[,1])
        cut <- polr.out$zeta
        coeff <- list(predictor,cut)
      }
    }
    else{
      ## use ordinal logistic regression create dummy variables(as.factor)
      if(min(table)<10){coeff <- NA}
      else{
        dat=data.frame(dat)
        dat[,2] <- as.factor(dat[,2]) 
        level.1 <- nlevels(as.factor(dat[,1]))
        polr.out <- polr(as.ordered(dat[,1])~dat[,2],data=dat)
        predictor <- polr.out$coefficients
        cut <- polr.out$zeta
        coeff <- list(predictor,cut)
      }
    }
  }
  else if("nom" %in% m.type){  ##logistic regression
    min.1 <- min(dat[,1])
    max.1 <- max(dat[,1])
    min.2 <- min(dat[,2])
    max.2 <- max(dat[,2])
    level.1 <- nlevels(as.factor(dat[,1]))
    level.2 <- nlevels(as.factor(dat[,2]))
    table <- table(dat[,1],dat[,2])
    if(n.type %in% c("con")){
      if(min(table(dat[,1]))<10){coeff <- NA}
      else{
        if(level.1==2){
          if(min(dat[,1])>0){dat[,1] <- dat[,1]-min.1}  ## change into 0 and 1 format
          mylogit<- glm(dat[,1]~dat[,2], family=binomial(link="logit"), na.action=na.pass)
          coeff <- mylogit$coefficients
        }
        else if(level.1 > 2) { ##multinomial logistic regression
          colnames(dat) <- c("missing","depend")
          row.names(dat) <- NULL
          dat=data.frame(dat)
          dat[,1]=as.factor(dat[,1])
          a <- mlogit.data(dat, varying=NULL, choice="missing", shape="wide")
          mlogit.model<- mlogit::mlogit(missing~1|depend,data=a,reflevel=1)  
          coeff <- as.matrix(mlogit.model$coefficient)
        }
      }
    }
    else if("ord" %in% n.type){
      if(level.1==2){      
        if(min(table)<10){coeff <- NA}
        else{
          if(min.1>0){dat[,1] <- dat[,1]-min.1}  ## change into 0 and 1 format
          mylogit<- glm(dat[,1]~dat[,2], family=binomial(link="logit"), na.action=na.pass)
          coeff <- mylogit$coefficients
        }
      }
      else if(level.1 > 2) { ##multinomial logistic regression
        if(min(table)<10){coeff <- NA}
        else{
          colnames(dat) <- c("missing","depend")
          row.names(dat) <- NULL
          dat=data.frame(dat)
          dat[,1]=as.factor(dat[,1])
          a <- mlogit.data(dat, varying=NULL, choice="missing", shape="wide")
          mlogit.model<- mlogit::mlogit(missing~1|depend,data=a,reflevel=1)  ##
          coeff <- as.matrix(mlogit.model$coefficient)
        }
      }
    }
    else if("nom" %in% n.type){## no sparse cell
      dat[,2] <- as.factor(dat[,2])         
      if(level.1==2){ ##logistic regression
        if(min(table)<10){coeff <- NA}
        else{
          if(min.1>0){dat[,1] <- dat[,1]-min.1}  ## change into 0 and 1 format
          mylogit<- glm(dat[,1]~dat[,2], family=binomial(link="logit"), na.action=na.pass)
          coeff <- mylogit$coefficients
        }
      }
      else if(level.1 > 2) { ##multinomial logistic regression
        if(min(table)<10){coeff <- NA}
        else{
          colnames(dat) <- c("missing","depend_value")
          row.names(dat) <- NULL
          dat=data.frame(dat)
          dat[,1]=as.factor(dat[,1])
          dat[,2]=as.factor(dat[,2])
          a <- mlogit.data(dat, varying=NULL, choice="missing", shape="wide")
          mlogit.model<- mlogit::mlogit(missing~1|depend_value,data=a,reflevel=1)  
          coeff <- as.matrix(mlogit.model$coefficient)  
        }
      }
    }
  }
  return(coeff)
}


### revise on 4/23/2013
take.mean <- function(result){
  l <- length(result)  ## result should be a list
  p <- length(result[[1]])
  mean.output = unlist(lapply(1:p,function(x) mean(unlist(lapply(1:l,function(y) result[[y]][x])))))
  mean.output
}


impute.by.combined.lsimput.mse <- function(type,knn.v,knn.s,mse,impute.by.type=FALSE){
  if(impute.by.type){
    if(length(which(names(mse)%in%"con"))>0){
      con.weight = mse[which(names(mse)%in%"con")]
    }
    if(length(which(names(mse)%in%"ord"))>0){
      ord.weight = mse[which(names(mse)%in%"ord")]
    }
    if(length(which(names(mse)%in%"nom"))>0){
      nom.weight = mse[which(names(mse)%in%"nom")]
    }
    if (type%in%"con"){imputed <- con.weight*knn.v+(1-con.weight)*knn.s}
    if (type%in%"nom"){
      if(nom.weight>0.5){imputed <- knn.v}
      else{imputed <- knn.s}
    }
    if (type%in%"ord"){imputed <- round(ord.weight*knn.v+(1-ord.weight)*knn.s)}
  }
  else{
    if (type%in%"con"){imputed <- mse[1]*knn.v+(1-mse[1])*knn.s}
    if (type%in%"nom"){
      if(mse[1]>0.5){imputed <- knn.v}
      else{imputed <- knn.s}
    }
    if (type%in%"ord"){imputed <- round(mse[1]*knn.v+(1-mse[1])*knn.s)}  
  }
  return(imputed)
}

loc.gen.missing <- function(mv.no,Type,nr,nc){
  col <- floor(mv.no/nr)+1
  row <- mv.no-nr*floor(mv.no/nr)
  if(row==0){(row=nr) & (col=col-1)}
  miss.type <- Type[col]  # type of missing value
  return(c(row,col,miss.type))
}



missForest <- function (xmis, maxiter = 10, ntree = 100, variablewise = FALSE, VarType,
                        decreasing = FALSE, verbose = FALSE, mtry = floor(sqrt(ncol(xmis))), 
                        replace = TRUE, classwt = NULL, cutoff = NULL, strata = NULL, 
                        sampsize = NULL, nodesize = NULL, maxnodes = NULL, xtrue = NA) 
{
  n <- nrow(xmis)
  p <- ncol(xmis)
  if (!is.null(classwt)) 
    stopifnot(length(classwt) == p, typeof(classwt) == "list")
  if (!is.null(cutoff)) 
    stopifnot(length(cutoff) == p, typeof(cutoff) == "list")
  if (!is.null(strata)) 
    stopifnot(length(strata) == p, typeof(strata) == "list")
  if (!is.null(nodesize)) 
    stopifnot(length(nodesize) == 2)
  if (any(apply(is.na(xmis), 2, sum) == n)) {
    indCmis <- which(apply(is.na(xmis), 2, sum) == n)
    xmis <- xmis[, -indCmis]
    p <- ncol(xmis)
    cat("  removed variable(s)", indCmis, "due to the missingness of all entries\n")
  }
  ximp <- xmis
  xAttrib <- lapply(xmis, attributes)
  varType <- character(p)
  for (t.co in 1:p) {
    if (is.null(xAttrib[[t.co]])) {
      varType[t.co] <- "numeric"
      ximp[is.na(xmis[, t.co]), t.co] <- mean(xmis[, t.co], 
                                              na.rm = TRUE)
    }
    else {
      varType[t.co] <- "factor"
      max.level <- max(table(ximp[, t.co]))
      class.assign <- sample(names(which(max.level == summary(ximp[, 
                                                                   t.co]))), 1)
      if (class.assign != "NA's") {
        ximp[is.na(xmis[, t.co]), t.co] <- class.assign
      }
      else {
        while (class.assign == "NA's") {
          class.assign <- sample(names(which(max.level == 
                                               summary(ximp[, t.co]))), 1)
        }
        ximp[is.na(xmis[, t.co]), t.co] <- class.assign
      }
    }
  }
  varType <- VarType
  NAloc <- is.na(xmis)
  noNAvar <- apply(NAloc, 2, sum)
  sort.j <- order(noNAvar)
  if (decreasing) 
    sort.j <- rev(sort.j)
  sort.noNAvar <- noNAvar[sort.j]
  Ximp <- vector("list", maxiter)
  iter <- 0
  k <- length(unique(varType))
  convNew <- rep(0, k)
  convOld <- rep(Inf, k)
  OOBerror <- numeric(p)
  names(OOBerror) <- varType
  if (k == 1) {
    if (unique(varType) == "numeric") {
      names(convNew) <- c("numeric")
    }
    else {
      names(convNew) <- c("factor")
    }
    convergence <- c()
    OOBerr <- numeric(1)
  }
  else {
    names(convNew) <- c("numeric", "factor")
    convergence <- matrix(NA, ncol = 2)
    OOBerr <- numeric(2)
  }
  stopCriterion <- function(varType, convNew, convOld, iter, 
                            maxiter) {
    k <- length(unique(varType))
    if (k == 1) {
      (convNew < convOld) & (iter < maxiter)
    }
    else {
      ((convNew[1] < convOld[1]) | (convNew[2] < convOld[2])) & 
        (iter < maxiter)
    }
  }
  while (stopCriterion(varType, convNew, convOld, iter, maxiter)) {
    if (iter != 0) {
      convOld <- convNew
      OOBerrOld <- OOBerr
    }
    #cat("  missForest iteration", iter + 1, "in progress...")
    t.start <- proc.time()
    ximp.old <- ximp
    for (s in 1:p) {
      varInd <- sort.j[s]
      if (noNAvar[[varInd]] != 0) {
        obsi <- !NAloc[, varInd]
        misi <- NAloc[, varInd]
        obsY <- ximp[obsi, varInd]
        obsX <- ximp[obsi, seq(1, p)[-varInd]]
        misX <- ximp[misi, seq(1, p)[-varInd]]
        typeY <- varType[varInd]
        if (typeY == "numeric") {
          RF <- randomForest(x = obsX, y = obsY, ntree = ntree, 
                             mtry = mtry, replace = replace, sampsize = if (!is.null(sampsize)) 
                               sampsize[[varInd]]
                             else if (replace) 
                               nrow(obsX)
                             else ceiling(0.632 * nrow(obsX)), nodesize = if (!is.null(nodesize)) 
                               nodesize[1]
                             else 1, maxnodes = if (!is.null(maxnodes)) 
                               maxnodes
                             else NULL)
          OOBerror[varInd] <- RF$mse[ntree]
          misY <- predict(RF, misX)
        }
        else {
          obsY <- factor(obsY)
          summarY <- summary(obsY)
          if (length(summarY) == 1) {
            misY <- factor(rep(names(summarY), sum(misi)))
          }
          else {
            RF <- randomForest(x = obsX, y = obsY, ntree = ntree, 
                               mtry = mtry, replace = replace, classwt = if (!is.null(classwt)) 
                                 classwt[[varInd]]
                               else rep(1, nlevels(obsY)), cutoff = if (!is.null(cutoff)) 
                                 cutoff[[varInd]]
                               else rep(1/nlevels(obsY), nlevels(obsY)), 
                               strata = if (!is.null(strata)) 
                                 strata[[varInd]]
                               else obsY, sampsize = if (!is.null(sampsize)) 
                                 sampsize[[varInd]]
                               else if (replace) 
                                 nrow(obsX)
                               else ceiling(0.632 * nrow(obsX)), nodesize = if (!is.null(nodesize)) 
                                 nodesize[2]
                               else 5, maxnodes = if (!is.null(maxnodes)) 
                                 maxnodes
                               else NULL)
            OOBerror[varInd] <- RF$err.rate[[ntree, 1]]
            misY <- predict(RF, misX)
          }
        }
        ximp[misi, varInd] <- misY
      }
    }
    #cat("done!\n")
    iter <- iter + 1
    Ximp[[iter]] <- ximp
    t.co2 <- 1
    for (t.type in names(convNew)) {
      t.ind <- which(varType == t.type)
      if (t.type == "numeric") {
        convNew[t.co2] <- sum((ximp[, t.ind] - ximp.old[, 
                                                        t.ind])^2)/sum(ximp[, t.ind]^2)
      }
      else {
        dist <- sum(as.character(as.matrix(ximp[, t.ind])) != 
                      as.character(as.matrix(ximp.old[, t.ind])))
        convNew[t.co2] <- dist/(n * sum(varType == "factor"))
      }
      t.co2 <- t.co2 + 1
    }
    if (!variablewise) {
      NRMSE <- sqrt(mean(OOBerror[varType == "numeric"])/var(as.vector(as.matrix(xmis[, 
                                                                                      varType == "numeric"])), na.rm = TRUE))
      PFC <- mean(OOBerror[varType == "factor"])
      if (k == 1) {
        if (unique(varType) == "numeric") {
          OOBerr <- NRMSE
          names(OOBerr) <- "NRMSE"
        }
        else {
          OOBerr <- PFC
          names(OOBerr) <- "PFC"
        }
      }
      else {
        OOBerr <- c(NRMSE, PFC)
        names(OOBerr) <- c("NRMSE", "PFC")
      }
    }
    else {
      OOBerr <- OOBerror
      names(OOBerr)[varType == "numeric"] <- "MSE"
      names(OOBerr)[varType == "factor"] <- "PFC"
    }
    if (any(!is.na(xtrue))) {
      err <- suppressWarnings(mixError(ximp, xmis, xtrue))
    }
    if (verbose) {
      delta.start <- proc.time() - t.start
      if (any(!is.na(xtrue))) {
      #  cat("    error(s):", err, "\n")
      }
      #cat("    estimated error(s):", OOBerr, "\n")
      #cat("    difference(s):", convNew, "\n")
      #cat("    time:", delta.start[3], "seconds\n\n")
    }
  }
  if (iter == maxiter) {
    if (any(is.na(xtrue))) {
      out <- list(ximp = Ximp[[iter]], OOBerror = OOBerr)
    }
    else {
      out <- list(ximp = Ximp[[iter]], OOBerror = OOBerr, 
                  error = err)
    }
  }
  else {
    if (any(is.na(xtrue))) {
      out <- list(ximp = Ximp[[iter - 1]], OOBerror = OOBerrOld)
    }
    else {
      out <- list(ximp = Ximp[[iter - 1]], OOBerror = OOBerrOld, 
                  error = suppressWarnings(mixError(Ximp[[iter - 
                                                            1]], xmis, xtrue)))
    }
  }
  class(out) <- "missForest"
  return(out)
}

###############################
## Generate imputability matrix ##
###############################
Imputability <- function(mv.error.var,mv.error.sub,row,col,Type,nr){
  nr = nr 
  nc = length(Type)
  By.var.imp = Imputability.Var(mv.error.var,col,Type)
  By.sub.imp = Imputability.Sub(mv.error.sub,row,nr)
  return(list(By.var.imp,By.sub.imp))
}
Imputability.exp <- function(mv.error.var,mv.error.sub,row,col,Type,nr){
  nr = nr 
  nc = length(Type)
  By.var.imp = Imputability.Var.exp(mv.error.var,col,Type)
  By.sub.imp = Imputability.Sub.exp(mv.error.sub,row,nr)
  return(list(By.var.imp,By.sub.imp))
}
## Variable imputability
Imputability.Var <- function(mv.error.var,col,Type){
  ## Type: each variable what type?
  Var.type.imputability <- function(mv.error.var,type){
    if(length(mv.error.var)==0){imputability=0.50}
    else{
      if(mean(mv.error.var)==0){imputability=10}
      ## if not covered, keep that
      else{
        if(type%in%c("con","ord")){
          imputability = log(1/sqrt(mean(mv.error.var)),base=10)
        }
        else{imputability = log(1/mean(mv.error.var),base=10)} 
      } 
    }
    return(imputability)
  }
  imp.var = sapply(c(1:length(Type)),function(x) Var.type.imputability(mv.error.var[which(col%in%x)],Type[x]))
  return(imp.var)
}
Imputability.Sub <- function(mv.error.sub,row,nr){
  ## Type: each variable what type?
  Sub.type.imputability <- function(mv.error.sub){
    if(length(mv.error.sub)==0){imputability=0.50}
    else{
      if(mean(mv.error.sub)==0){imputability=10}
      ## if not covered, keep that
      else{imputability = log(1/sqrt(mean(mv.error.sub)),base=10)} 
    }
    return(imputability)
  }
  imp.sub = sapply(c(1:nr),function(x) Sub.type.imputability(mv.error.sub[which(row%in%x)]))
  return(imp.sub)
}

Imputability.Var.exp <- function(mv.error.var,col,Type){
  ## Type: each variable what type?
  Var.type.imputability <- function(mv.error.var,type){
    if(length(mv.error.var)==0){imputability=0.5}
    else{
      if(mean(mv.error.var)==0){imputability=1}
      ## if not covered, keep that
      else{
        if(type%in%c("con","ord")){
          imputability = exp(-sqrt(mean(mv.error.var)))
        }
        else{imputability = exp(-mean(mv.error.var))} 
      } 
    }
    return(imputability)
  }
  imp.var = sapply(c(1:length(Type)),function(x) Var.type.imputability(mv.error.var[which(col%in%x)],Type[x]))
  return(imp.var)
}
Imputability.Sub.exp <- function(mv.error.sub,row,nr){
  ## Type: each variable what type?
  Sub.type.imputability <- function(mv.error.sub){
    if(length(mv.error.sub)==0){imputability=0.50}
    else{
      if(mean(mv.error.sub)==0){imputability=1}
      ## if not covered, keep that
      else{imputability = exp(-sqrt(mean(mv.error.sub)))} 
    }
    return(imputability)
  }
  imp.sub = sapply(c(1:nr),function(x) Sub.type.imputability(mv.error.sub[which(row%in%x)]))
  return(imp.sub)
}


SummaryResult <- function(Error,miss.type){
  result.con <- sqrt(mean(Error[miss.type=="con"]))
  result.nom <- sum(Error[miss.type=="nom"])/sum(miss.type=="nom")
  result.ord <- sqrt(mean(Error[miss.type=="ord"]))  
  return(c("Con"=result.con,"Nom"=result.nom,"Ord"=result.ord))
}


Adaptive.Weight.Impute <- function(accu.v,accu.s,row,col,miss.type,final.var,final.sub,R.max,Global.weight.result){
  indicator.v = split(accu.v,col)
  indicator.s = split(accu.s,col)
  out.impute.adaptive.global = rep(0,length(accu.v))
  out.impute.adaptive.var.type = rep(0,length(accu.v))
  Adaptive.weight = vector("list",length=length(R.max))
  
  Each.variable.adaptive <- function(no.var,col,indicator.v,indicator.s,miss.type,final.var,final.sub,R.max,Global.weight.result){
    if(is.na(R.max[no.var])){
      Global.weight.lsimput = Global.weight.result[which(col==no.var)]
      p=0.49
    }
    else{
      Range.Rmax = c(R.max[no.var]-0.05,R.max[no.var]+0.05)
      select = which((R.max>=Range.Rmax[1])&(R.max<=Range.Rmax[2]))
      if(length(select)<10){select = order(abs(R.max[no.var]-R.max),decreasing=FALSE)[1:10]}
      accu.v.sub = unlist(indicator.v[select])
      accu.s.sub = unlist(indicator.s[select])
      ## apply LSimpute global weight:
      sum_e_var_2=sum(accu.v.sub)
      sum_e_sub_2=sum(accu.s.sub)
      sum_e_var_sub=sum(sqrt(accu.v.sub)*sqrt(accu.s.sub))
      if((sum_e_var_2-2*sum_e_var_sub+sum_e_sub_2)==0){p=0.51}
      else{
        p = (sum_e_sub_2 - sum_e_var_sub)/(sum_e_var_2-2*sum_e_var_sub+sum_e_sub_2)
        if(p < 0){p = 0}
        else if(p > 1){p = 1}        
      }
      Global.weight.lsimput <- sapply(which(col%in%no.var),function(x) impute.by.combined.lsimput.mse(miss.type[x],final.var[x],final.sub[x],c(rep(p,3))))
    }
    return(list(Global.weight.lsimput,p))
  }
  
  for(i in 1:length(R.max)){
    temp = Each.variable.adaptive(i,col,indicator.v,indicator.s,miss.type,final.var,final.sub,R.max,Global.weight.result)
    out.impute.adaptive.global[which(col==i)] = temp[[1]]
    Adaptive.weight[[i]] = temp[[2]]
  }
  return(list(out.impute.adaptive.global,Adaptive.weight))
} 

###########################
## Secondary Missing value ##
###########################

KNN.imp.2 <- function(n,perc,k,MV1,Complete,missing.data.1,Type){
  ## Generate missing value #
  missing.data.2 <- missing.no.2(MV1,n,perc,missing.data.1)
  ## secondary missing calculation function
  Secondary.missing.simulation <- function(MV1,Complete,mv.no,missing.data.1,ind,Type){
    print(ind)
    nc <- ncol(MV1)
    nr <- nrow(MV1)
    mv.comp.1 <- MV1
    Missing <- length(mv.no)
    ## position of missing
    missing.info = t(sapply(mv.no,function(x) loc.gen.missing(x,Type,nr,nc)))
    col <- as.numeric(missing.info[,2])
    row <- as.numeric(missing.info[,1])
    miss.type <- missing.info[,3]  
    ## generate missingness   
    for (j in 1:Missing)
    {
      mv.comp.1[row[j],col[j]] <- NA
    }
    dist.var <- mixedDist(mv.comp.1,Type)
    dist.var <- as.matrix(dist.var)
    Cal.R.max <- function(x){
      if(length(na.omit(dist.var[-x,x]))==0){return(NA)}
      else{return(max(as.vector(na.omit(1-dist.var[-x,x]))))}
    }
    R.max = sapply(1:ncol(dist.var),Cal.R.max)
    mv.comp.2 <- as.data.frame(mv.comp.1)
    for(i in 1:length(which(Type=="con"))){
      mv.comp.2[,which(Type=="con")[i]] <- as.numeric(mv.comp.1[,which(Type=="con")[i]])}
    for(i in 1:length(which(Type=="ord"))){
      mv.comp.2[,which(Type=="ord")[i]] <- as.ordered(mv.comp.1[,which(Type=="ord")[i]])}
    for(i in 1:length(which(Type=="nom"))){
      mv.comp.2[,which(Type=="nom")[i]] <- as.factor(mv.comp.1[,which(Type=="nom")[i]])}
    ## calculate each imputed value of each missingness
    dist.sub <- as.matrix(daisy(mv.comp.2,metric="gower"))
    col.i <- vector("list",length=Missing)
    colnames(dist.var) <- colnames(MV1)
    row.names(dist.var) <- colnames(MV1)
    true.value <- vector(length=Missing)
    w.1 <- vector("list",length=Missing) 
    
    
    ## prepare for KNN.V
    ## Get col.i true.value
    for (e in  1:Missing){
      ## mv.no: from 1 to perc * row *col
      ## neighbor.no: from 1 to k 
      true.value[e] <- MV1[row[e],col[e]] 
      candidate <- dist.var[col[e],-c(which(is.na(mv.comp.1[row[e],])==TRUE),which(is.na(dist.var[col[e],])==TRUE))] 
      index=order(candidate)[1:k]
      neighbor <- candidate[index]
      ## col.i the column # for each neighbor
      col.i[[e]] <- which(colnames(mv.comp.1)%in%row.names(as.matrix(neighbor)))
      w.1[[e]] <- (1-dist.var[col[e],col.i[[e]]])^2/(1-(1-dist.var[col[e],col.i[[e]]])^2+10^(-6))
    }
    mean.imp <- sapply(1:ncol(MV1),function(x) each.mv.m.i(x,mv.comp.1,Type))
    imputed.m.i <- sapply(1:Missing,function(x) mean.imp[col[x]])
    accu.m.i <- sapply(1:Missing,function(x) Evaluate(imputed.m.i[x],true.value[x],miss.type[x],col[x],Complete))
    
    #########################################################################
    ###### Get possible regression coefficient needed and mean imputation ####
    #########################################################################
    regression.r <- vector("list",length=ncol(MV1))
    neighbor.r <- vector("list",length=ncol(MV1))
    mean.imp <- vector(length=ncol(MV1))
    for (i in 1:ncol(MV1)){
      mv.id <- which(col==i)
      if(length(mv.id)==0){neighbor.r[[i]] <- NA
      } else if (length(mv.id)==1){neighbor.r[[i]] <- col.i[[mv.id[1]]]
      } else {
        neighbor.u <- col.i[[mv.id[1]]]
        for (h in 1:(length(mv.id)-1)){
          neighbor.u <- unique(c(neighbor.u,col.i[[mv.id[h+1]]]))
        }
        neighbor.r[[i]] <- neighbor.u
      }
      if (length(neighbor.r[[i]])>0){
        n.n <- length(neighbor.r[[i]])
        regression.each <- lapply(as.list(1:n.n),function(z) cal.reg.coef(mv.comp.1,i,neighbor.r[[i]][z],Type))
        regression.r[[i]] <- regression.each}
      mean.imp[i] <- each.mv.m.i(i,mv.comp.1,Type)
    }  
    ###### Get imputed value (using output from regression.r)
    imp <- vector("list",length=Missing)
    for (i in 1:Missing){
      if(length(col.i[[i]])>0){
        temp = sapply(1:length(col.i[[i]]),function(z) Imp.Single(neighbor.r[[col[i]]],regression.r[[col[i]]],col[i],row[i],col.i[[i]][z],Type,mv.comp.1))
      }
      else{temp <- sample(na.omit(mv.comp.1[,col[i]]),k)
      }
      imp[[i]] <- na.omit(temp)
      if(length(which(is.na(temp)==TRUE))==0){w.1[[i]] <- w.1[[i]]}
      else{w.1[[i]] <- w.1[[i]][-which(is.na(temp)==TRUE)]}
    }
    k.imputed.value.1 <- imp
    accu.v <- vector(length=Missing)
    final.var <- vector(length=Missing)
    for (q in 1:Missing){
      if(length(w.1[[q]])==0){w.1[[q]] <- rep(1,5)}
      final.var[q] <- determin.i(k.imputed.value.1[[q]],w.1[[q]],miss.type[q],1)
      accu.v[q] <- Evaluate(final.var[q],true.value[q],miss.type[q],col[q],Complete)
    }
    print("accu.v")
    #####################################################
    ## KNN.s: Using k nearest subject do MV imputation ##
    #####################################################
    ## calculate the accuracy of imputation
    ## calculate the accuracy of random imputation
    ## calculate the accuracy of mean/majority vote imputation
    final.sub <- vector(length=Missing)
    accu.s <- vector(length=Missing)
    k.imputed.value.2 <- vector("list",length=Missing)
    w.2 <- vector("list",length=Missing)
    r.2 = vector("list",length=Missing)
    for (i in 1:Missing){
      candidate <- dist.sub[-c(which(is.na(mv.comp.1[,col[i]])==TRUE),row[i]),row[i]]
      dist <- candidate[order(candidate)][1:k]
      k.imputed.value.2[[i]] <- MV1[which(row.names(mv.comp.1)%in%row.names(as.matrix(dist))),col[i]]
      row.i <- which(row.names(mv.comp.1)%in%row.names(as.matrix(dist)))
      w.2[[i]] <- (1- dist.sub[row[i],row.i])^2/(1-(1- dist.sub[row[i],row.i])^2+10^(-6))
      r.2[[i]] <- 1- dist.sub[row[i],row.i]
      final.sub[i] <- determin.i(k.imputed.value.2[[i]],w.2[[i]],miss.type[i],1)
      ## calculate the random imputation value
      accu.s[i] <- Evaluate(final.sub[i],true.value[i],miss.type[i],col[i],Complete)
    }
    print("accu.s")
    
    ## those weight are for first set missing values
    ## apply LSimpute global weight:
    sum_e_var_2=sum(accu.v)
    sum_e_sub_2=sum(accu.s)
    sum_e_var_sub=sum(sqrt(accu.v)*sqrt(accu.s))
    ####################
    ## Global weight
    ####################
    p = (sum_e_sub_2 - sum_e_var_sub)/(sum_e_var_2-2*sum_e_var_sub+sum_e_sub_2)
    if((sum_e_var_2-2*sum_e_var_sub+sum_e_sub_2)==0){p=0.51}
    else{
      if(p < 0){p = 0}
      else if(p > 1){p = 1}  
      else{p=p}
    }
    tmp = Get.weight.Secondary.missing(3,0.05,5,mv.comp.1,Complete,mv.no,missing.data.1,Type)
    weighted.mse.lsimput <- sapply(1:Missing,function(x) impute.by.combined.lsimput.mse(miss.type[x],final.var[x],final.sub[x],c(rep(tmp[[1]][[1]],3))))
    Global.weight.result <- sapply(1:Missing,function(x) Evaluate(weighted.mse.lsimput[x],true.value[x],miss.type[x],col[x],Complete))
    
    Adaptive.result = Adaptive.Weight.Impute(accu.v,accu.s,row,col,miss.type,final.var,final.sub,R.max,weighted.mse.lsimput)
    Adaptive.weight = Adaptive.result[[2]]    
    ## [[1]] Global [[2]] Adaptive
    Adaptive.input = sapply(1:Missing,function(x) impute.by.combined.lsimput.mse(miss.type[x],final.var[x],final.sub[x],c(rep(tmp[[1]][[2]][[col[x]]],3))))
    print("accu.adapt")
    
    Adaptive.weight.result <- sapply(1:Missing,function(x) Evaluate(Adaptive.input[x],true.value[x],miss.type[x],col[x],Complete))
    Type.input = Type
    Type.input[which(Type%in%c("con","ord"))] = "numeric"
    Type.input[which(Type%in%c("nom"))] = "factor"
    
    mv.comp.3 <- as.data.frame(mv.comp.1)
    for(i in 1:length(which(Type=="con"))){
      mv.comp.3[,which(Type=="con")[i]] <- as.numeric(mv.comp.1[,which(Type=="con")[i]])}
    for(i in 1:length(which(Type=="ord"))){
      mv.comp.3[,which(Type=="ord")[i]] <- as.ordered(mv.comp.1[,which(Type=="ord")[i]])}
    for(i in 1:length(which(Type=="nom"))){
      mv.comp.3[,which(Type=="nom")[i]] <- as.factor(mv.comp.1[,which(Type=="nom")[i]])}
    
    Rf.imputed.data <- missForest(mv.comp.1[,1:ncol(mv.comp.1)], VarType=Type.input[1:ncol(mv.comp.1)], xtrue = NA, verbose = TRUE)
    
    accu.rf <- sapply(1:Missing,function(x) Evaluate(Rf.imputed.data[[1]][row[x],col[x]],Complete[row[x],col[x]],miss.type[x],col[x],Complete))
    print("accu.rf")
    
    
    result = list(SummaryResult(accu.v,miss.type),SummaryResult(accu.s,miss.type),SummaryResult(Global.weight.result,miss.type),SummaryResult(Adaptive.weight.result,miss.type),SummaryResult(accu.rf,miss.type),SummaryResult(accu.m.i,miss.type),p,Adaptive.weight)
    Error = list(accu.v,accu.s,Global.weight.result,Adaptive.weight.result,accu.rf,accu.m.i,p,Adaptive.weight)
    
    names(result) = c("KNN-v(2)","KNN-s(2)","KNN-global(2)","KNN-adaptive(2)","Random Forest","Mean Imputation","p_hat","Apdaptive-weight")
    Imputability.matrix.out.exp = Imputability.exp(accu.v,accu.s,row,col,Type,nrow(MV1))
    
    return(list(result,Imputability.matrix.out.exp,Error))
  }
  Result.n = lapply(as.list(1:n),function(x) Secondary.missing.simulation(MV1,Complete,missing.data.2[[x]],missing.data.1,x,Type))    
  return(Result.n)
}


Get.weight.Secondary.missing <- function(n,perc,k,MV2,Complete,missing.data.1,missing.data.2,Type){
  ## Generate missing value #
  missing.data.3 <- missing.no.3(MV2,n,perc,missing.data.1,missing.data.2)
  ## secondary missing calculation function
  Third.missing.simulation <- function(MV2,Complete,mv.no,ind,Type){
    #print(ind)
    nc <- ncol(MV2)
    nr <- nrow(MV2)
    mv.comp.2 <- MV2
    Missing <- length(mv.no)
    ## position of missing
    missing.info = t(sapply(mv.no,function(x) loc.gen.missing(x,Type,nr,nc)))
    col <- as.numeric(missing.info[,2])
    row <- as.numeric(missing.info[,1])
    miss.type <- missing.info[,3]  
    ## generate missingness   
    for (j in 1:Missing)
    {
      mv.comp.2[row[j],col[j]] <- NA
    }
    dist.1 <- mixedDist(mv.comp.2,Type)
    dist.var <- dist.1 + t(dist.1)
    dist.var <- as.matrix(dist.var)
    Cal.R.max <- function(x){
      if(length(na.omit(dist.var[-x,x]))==0){return(NA)}
      else{return(max(as.vector(na.omit(1-dist.var[-x,x]))))}
    }
    R.max = sapply(1:ncol(dist.var),Cal.R.max)
    mv.comp.3 <- as.data.frame(mv.comp.2)
    for(i in 1:length(which(Type=="con"))){
      mv.comp.3[,which(Type=="con")[i]] <- as.numeric(mv.comp.3[,which(Type=="con")[i]])}
    for(i in 1:length(which(Type=="ord"))){
      mv.comp.3[,which(Type=="ord")[i]] <- as.ordered(mv.comp.3[,which(Type=="ord")[i]])}
    for(i in 1:length(which(Type=="nom"))){
      mv.comp.3[,which(Type=="nom")[i]] <- as.factor(mv.comp.3[,which(Type=="nom")[i]])}
    ## calculate each imputed value of each missingness
    dist.sub <- as.matrix(daisy(mv.comp.3,metric="gower"))
    col.i <- vector("list",length=Missing)
    colnames(dist.var) <- colnames(MV2)
    row.names(dist.var) <- colnames(MV2)
    true.value <- vector(length=Missing)
    w.1 <- vector("list",length=Missing)    
    ## prepare for KNN.V
    ## Get col.i true.value
    for (e in  1:Missing){
      ## mv.no: from 1 to perc * row *col
      ## neighbor.no: from 1 to k 
      true.value[e] <- MV2[row[e],col[e]] 
      candidate <- dist.var[col[e],-c(which(is.na(mv.comp.2[row[e],])==TRUE),which(is.na(dist.var[col[e],])==TRUE))] 
      index=order(candidate)[1:k]
      neighbor <- candidate[index]
      ## col.i the column # for each neighbor
      col.i[[e]] <- which(colnames(mv.comp.2)%in%row.names(as.matrix(neighbor)))
      w.1[[e]] <- (1-dist.var[col[e],col.i[[e]]])^2/(1-(1-dist.var[col[e],col.i[[e]]])^2+10^(-6))
    }
    #########################################################################
    ###### Get possible regression coefficient needed and mean imputation ####
    #########################################################################
    regression.r <- vector("list",length=ncol(MV2))
    neighbor.r <- vector("list",length=ncol(MV2))
    mean.imp <- vector(length=ncol(MV2))
    for (i in 1:ncol(MV2)){
      mv.id <- which(col==i)
      if(length(mv.id)==0){neighbor.r[[i]] <- NA
      } else if (length(mv.id)==1){neighbor.r[[i]] <- col.i[[mv.id[1]]]
      } else {
        neighbor.u <- col.i[[mv.id[1]]]
        for (h in 1:(length(mv.id)-1)){
          neighbor.u <- unique(c(neighbor.u,col.i[[mv.id[h+1]]]))
        }
        neighbor.r[[i]] <- neighbor.u
      }
      if (length(neighbor.r[[i]])>0){
        n.n <- length(neighbor.r[[i]])
        regression.each <- lapply(as.list(1:n.n),function(z) cal.reg.coef(mv.comp.2,i,neighbor.u[z],Type))
        regression.r[[i]] <- regression.each}
      mean.imp[i] <- each.mv.m.i(i,mv.comp.2,Type)
    }  
    ###### Get imputed value (using output from regression.r)
    imp <- vector("list",length=Missing)
    for (i in 1:Missing){
      if(length(col.i[[i]])>0){
        temp = sapply(1:length(col.i[[i]]),function(z) Imp.Single(neighbor.r[[col[i]]],regression.r[[col[i]]],col[i],row[i],col.i[[i]][z],Type,mv.comp.2))
      }
      else{temp <- sample(na.omit(mv.comp.2[,col[i]]),k)
      }
      imp[[i]] <- na.omit(temp)
      if(length(which(is.na(temp)==TRUE))==0){w.1[[i]] <- w.1[[i]]}
      else{w.1[[i]] <- w.1[[i]][-which(is.na(temp)==TRUE)]}
    }
    k.imputed.value.1 <- imp
    accu.v <- vector(length=Missing)
    final.var <- vector(length=Missing)
    for (q in 1:Missing){
      if(length(w.1[[q]])==0){w.1[[q]] <- rep(1,k)}
      final.var[q] <- determin.i(k.imputed.value.1[[q]],w.1[[q]],miss.type[q],1)
      accu.v[q] <- Evaluate(final.var[q],true.value[q],miss.type[q],col[q],Complete)
    }
    #####################################################
    ## KNN.s: Using k nearest subject do MV imputation ##
    #####################################################
    ## calculate the accuracy of imputation
    ## calculate the accuracy of random imputation
    ## calculate the accuracy of mean/majority vote imputation
    final.sub <- vector(length=Missing)
    accu.s <- vector(length=Missing)
    k.imputed.value.2 <- vector("list",length=Missing)
    w.2 <- vector("list",length=Missing)
    r.2 = vector("list",length=Missing)
    for (i in 1:Missing){
      candidate <- dist.sub[-c(which(is.na(mv.comp.2[,col[i]])==TRUE),row[i]),row[i]]
      dist <- candidate[order(candidate)][1:k]
      k.imputed.value.2[[i]] <- MV2[which(row.names(mv.comp.2)%in%row.names(as.matrix(dist))),col[i]]
      row.i <- which(row.names(mv.comp.2)%in%row.names(as.matrix(dist)))
      w.2[[i]] <- (1- dist.sub[row[i],row.i])^2/(1-(1- dist.sub[row[i],row.i])^2+10^(-6))
      r.2[[i]] <- 1- dist.sub[row[i],row.i]
      final.sub[i] <- determin.i(k.imputed.value.2[[i]],w.2[[i]],miss.type[i],1)
      ## calculate the random imputation value
      accu.s[i] <- Evaluate(final.sub[i],true.value[i],miss.type[i],col[i],Complete)
    }
    ## apply LSimpute global weight:
    sum_e_var_2=sum(accu.v)
    sum_e_sub_2=sum(accu.s)
    sum_e_var_sub=sum(sqrt(accu.v)*sqrt(accu.s))
    ####################
    ## Global weight
    ####################
    p = (sum_e_sub_2 - sum_e_var_sub)/(sum_e_var_2-2*sum_e_var_sub+sum_e_sub_2)
    if((sum_e_var_2-2*sum_e_var_sub+sum_e_sub_2)==0){p=0.51}
    else{
      if(p < 0){p = 0}
      else if(p > 1){p = 1}  
      else{p=p}
    }
    weighted.mse.lsimput <- sapply(1:Missing,function(x) impute.by.combined.lsimput.mse(miss.type[x],final.var[x],final.sub[x],c(rep(p,3))))
    
    ####################
    ## Adaptive weight
    ####################
    Adaptive.result = Adaptive.Weight.Impute(accu.v,accu.s,row,col,miss.type,final.var,final.sub,R.max,weighted.mse.lsimput)
    
    Adaptive.weight = Adaptive.result[[2]]
    return(list(p,Adaptive.weight))
  }
  Result.n = lapply(as.list(1:n),function(x) Third.missing.simulation(MV2,Complete,missing.data.3[[x]],x,Type))    
  return(Result.n)
}