#' Self-Train Imputation for High dimensional Phenome data
#'
#' Take in any phenome data with missing values to self train best methods for different types of variables.
#' @param Data A data matrix with rows being subjects and column being variables
#' @param Type vector of variable types in Data. "con" for continuous variable; "nom" for nominal variables(including binary and multi-level variables); "ord" for ordinal variables.
#' @param k Number of neighbors prefered in KNN methods
#' @param n.re Number of second layer missing values being generated

#' @return a list with first element being the imputed dataset; the second element being methods selected by each type of variables; third element is the unimputable cells within the original missing data(represented by row, col and variable type of missing value )
#' @export
#' @examples
#' set.seed(1234)
#' Data = cbind(rnorm(100,0,4),rnorm(100,0,7),rnorm(100,5,4),rnorm(100,-3,4),rnorm(100,0,4),sample(1:4,100,replace=TRUE),sample(1:2,100,replace=TRUE),sample(1:3,100,replace=TRUE),sample(1:20,100,replace=TRUE),sample(1:10,100,replace=TRUE))
#' Data = cbind(Data,Data)
#' colnames(Data) = paste("var",1:20,sep="")
#' row.names(Data) = paste("sub",1:100,sep="")
#' Type = c(rep("con",5),rep("nom",3),rep("ord",2))
#' Type = c(Type,Type)
#' for(i in 1:ncol(Data)){
#'   Data[sample(1:nrow(Data),5),i] = NA
#' }
#' tmp = PhenomeImpute(Data,Type,5,5)


#' data(COPD)
#' set.seed(12345)
#' for(i in 1:ncol(COPD[[1]])){
#' COPD[[1]][sample(1:nrow(COPD[[1]]),5),i] = NA
#' }
#' COPD.impute=PhenomeImpute(COPD[[1]],COPD[[2]],5,2)



PhenomeImpute <- function(Data,Type,k,n.re){
  
  Data.Impute = Data
  
  Missing = sum(is.na(Data))
  nc <- ncol(Data)
  nr <- nrow(Data)
  missing.data = which(is.na(Data))
  missing.info = t(sapply(missing.data,function(x) loc.gen.missing(x,Type,nr,nc)))
  col <- as.numeric(missing.info[,2])
  row <- as.numeric(missing.info[,1])
  miss.type <- missing.info[,3]  
  
  Error.all.method = matrix(NA,length(missing.data),6)
  colnames(Error.all.method) = c("KNN-V","KNN-S","KNN-H","KNN-A","MeanImp","RF")
  #############################
  ## Secondary Missing value ##

  mse <- KNN.imp.2(n.re,0.05,k,Data,Data,missing.data,Type)
  
  global.weight = mean(unlist(lapply(mse,function(x) x[[1]][[7]])))
  adaptive.weight = apply(matrix(unlist(lapply(mse,function(x) x[[1]][[8]])),nrow=n.re,byrow=TRUE),2,mean)
  Result.secondary = lapply(1:n.re,function(x) rbind(mse[[x]][[1]][[1]],mse[[x]][[1]][[2]],mse[[x]][[1]][[3]],mse[[x]][[1]][[4]],mse[[x]][[1]][[5]],mse[[x]][[1]][[6]]))
  method=c("KNN-V","KNN-S","KNN-H","KNN-A","RF","MeanImp")
  Result.secondary.mean = Reduce('+', Result.secondary)/n.re
  
  
  Optimal.Method.out = apply(Result.secondary.mean,2,function(y) method[order(y,decreasing=FALSE)[1]])
  names(Optimal.Method.out) = c("con","nom","ord")
  
  ## 1. take max and then average over n.re repeats
  cal.imputability.exp <- function(x,mse){
    Imputability.value = matrix(0,nr,nc)
    By.var.imp = mse[[x]][[2]][[1]]
    By.sub.imp = mse[[x]][[2]][[2]]
    for(i in 1:nr){
      for(j in 1:nc){
        Imputability.value[i,j] = max(By.var.imp[j],By.sub.imp[i])
      }
    }
    return(Imputability.value)
  }  
  imputability.list.exp = lapply(1:n.re,function(x) cal.imputability.exp(x,mse))
  imputability.mean.exp = Reduce('+', imputability.list.exp)/n.re
  
  print("Secondary Missing")
  
  
  if(any(Optimal.Method.out%in%c("KNN-V","KNN-S","KNN-H","KNN-A","MeanImp"))){

    #####################################################
    ## KNN.v: Using k nearest subject do MV imputation ##
    #####################################################

    dist.1 <- mixedDist(Data,Type)
    dist.var <- dist.1 + t(dist.1)
    dist.var <- as.matrix(dist.var)
    Data.1 <- as.data.frame(Data)
    for(i in 1:length(which(Type=="con"))){
      Data.1[,which(Type=="con")[i]] <- as.numeric(Data[,which(Type=="con")[i]])}
    for(i in 1:length(which(Type=="ord"))){
      Data.1[,which(Type=="ord")[i]] <- as.ordered(Data[,which(Type=="ord")[i]])}
    for(i in 1:length(which(Type=="nom"))){
      Data.1[,which(Type=="nom")[i]] <- as.factor(Data[,which(Type=="nom")[i]])}
    ## calculate each imputed value of each missingness
    dist.sub <- as.matrix(daisy(Data.1,metric="gower"))
    row.names(dist.sub) = colnames(dist.sub) = row.names(Data)
    col.i <- vector("list",length=Missing)
    colnames(dist.var) <- colnames(Data)
    row.names(dist.var) <- colnames(Data)
    w.1 <- vector("list",length=Missing)
    r.1 = vector("list",length=Missing)
    
    for (e in  1:Missing){    
      candidate <- dist.var[col[e],-c(which(is.na(Data[row[e],])==TRUE),which(is.na(dist.var[col[e],])==TRUE))] 
      index=order(candidate)[1:k]
      neighbor <- candidate[index]
      ## col.i the column # for each neighbor
      col.i[[e]] <- which(colnames(Data)%in%row.names(as.matrix(neighbor)))
      w.1[[e]] <- (1-dist.var[col[e],col.i[[e]]])^2/(1-(1-dist.var[col[e],col.i[[e]]])^2+10^(-6))
    }
    #########################################################################
    ###### Get possible regression coefficient needed and mean imputation ####
    #########################################################################
    regression.r <- vector("list",length=ncol(Data))
    neighbor.r <- vector("list",length=ncol(Data))
    mean.imp <- vector(length=ncol(Data))
    for (i in 1:ncol(Data)){
      mv.id <- which(col==i)
      if(length(mv.id)==0){neighbor.r[[i]] <- NA
      }else if(length(mv.id)==1){neighbor.r[[i]] <- col.i[[mv.id[1]]]}
      else{
        neighbor.u <- col.i[[mv.id[1]]]
        for (h in 1:(length(mv.id)-1)){
          neighbor.u <- unique(c(neighbor.u,col.i[[mv.id[h+1]]]))
        }
        neighbor.r[[i]] <- neighbor.u
      }
      if (length(na.omit(neighbor.r[[i]]))>0){
        n.n <- length(neighbor.u)
        regression.each <- vector("list",length=n.n) ##k:no of neighbor
        for (u in 1:n.n){
          regression.each[[u]] <- cal.reg.coef(Data,i,neighbor.r[[i]][u],Type)
        }
        regression.r[[i]] <- regression.each}
      else{
        regression.r[[i]] =NA
      }
      mean.imp[i] <- each.mv.m.i(i,Data,Type)    
    }  
    imp <- vector("list",length=Missing)
    
    for (i in 1:Missing){
      temp <- vector(length=length(col.i[[i]]))
      if(length(col.i[[i]])>0){
        for (j in 1:length(col.i[[i]])){
          temp[j] <- Imp.Single(neighbor.r[[col[i]]],regression.r[[col[i]]],col[i],row[i],col.i[[i]][j],Type,Data)
        }
      }
      else{temp <- sample(na.omit(Data[,col[i]]),k)
      }
      imp[[i]] <- na.omit(temp)
      if(length(which(is.na(temp)==TRUE))==0){w.1[[i]] <- w.1[[i]]}
      else{w.1[[i]] <- w.1[[i]][-which(is.na(temp)==TRUE)]}
      
    }
    k.imputed.value.1 <- imp
    
    final.var <- vector(length=Missing)
    final.sub <- vector(length=Missing)
    for (q in 1:Missing){
      if(length(w.1[[q]])==0){w.1[[q]] <- rep(1,k)}
      final.var[q] <- determin.i(k.imputed.value.1[[q]],w.1[[q]],miss.type[q],1)
    }    
    
    #####################################################
    ## KNN.s: Using k nearest subject do MV imputation ##
    #####################################################
    
    imputed <- vector(length=Missing)
    imputed.m.i <- vector(length=Missing)
    k.imputed.value.2 <- vector("list",length=Missing)
    w.2 <- vector("list",length=Missing)
    
    for (i in 1:Missing){
      candidate <- dist.sub[-c(which(is.na(Data[,col[i]])==TRUE),row[i]),row[i]]
      dist <- candidate[order(candidate)][1:k]
      k.imputed.value.2[[i]] <- Data[which(row.names(Data)%in%row.names(as.matrix(dist))),col[i]]
      row.i <- which(row.names(Data)%in%row.names(as.matrix(dist)))
      w.2[[i]] <- (1- dist.sub[row[i],row.i])^2/(1-(1- dist.sub[row[i],row.i])^2+10^(-6))
      final.sub[i] <- determin.i(k.imputed.value.2[[i]],w.2[[i]],miss.type[i],1)
      imputed.m.i[i] <- mean.imp[col[i]]
    }

    ###############################################################
    ## KNN.h and KNN.a: Using k nearest subject do MV imputation ##
    ###############################################################
    weighted.mse.lsimput <- vector(length=Missing)
    Adaptive.result <- vector(length=Missing)
    for (i in 1:Missing){
      type <- Type[col[i]] 
      weighted.mse.lsimput[i] <- impute.by.combined.lsimput.mse(type,final.var[i],final.sub[i],rep(global.weight,3))
      Adaptive.result[i] = impute.by.combined.lsimput.mse(type,final.var[i],final.sub[i],rep(adaptive.weight[col[i]],3))
    }
    Error.all.method[,5] = imputed.m.i
    Error.all.method[,4] = Adaptive.result
    Error.all.method[,3] = weighted.mse.lsimput
    Error.all.method[,2] = final.sub
    Error.all.method[,1] = final.var
  }
  
  if(any(Optimal.Method.out%in%c("RF"))){
    ## Random forest
    Type.input = Type
    Type.input[which(Type%in%c("con","ord"))] = "numeric"
    Type.input[which(Type%in%c("nom"))] = "factor"
    Rf.imputed.data <- missForest(Data, VarType=Type.input,  verbose = TRUE)
    Error.all.method[,6] = sapply(1:length(missing.data),function(x) Rf.imputed.data$ximp[row[x],col[x]])
    print("random forest")
  }
  ## Continuous
  
  Con.impute = Error.all.method[which(miss.type%in%"con"),which(colnames(Error.all.method)%in%Optimal.Method.out[1])]
  for (i in 1:length(which(miss.type=="con"))){
    Data.Impute[row[which(miss.type=="con")[i]],col[which(miss.type=="con")[i]]] = Con.impute[i]
  }
  Nom.impute = Error.all.method[which(miss.type%in%"nom"),which(colnames(Error.all.method)%in%Optimal.Method.out[2])]
  for (i in 1:length(which(miss.type=="nom"))){
    Data.Impute[row[which(miss.type=="nom")[i]],col[which(miss.type=="nom")[i]]] = Nom.impute[i]
  }
  Ord.impute = Error.all.method[which(miss.type%in%"ord"),which(colnames(Error.all.method)%in%Optimal.Method.out[3])]
  for (i in 1:length(which(miss.type=="ord"))){
    Data.Impute[row[which(miss.type=="ord")[i]],col[which(miss.type=="ord")[i]]] = round(Ord.impute[i])
  }
  
  Imputed.value=list(Con.impute=cbind(Con.impute,row[which(miss.type=="con")],col[which(miss.type=="con")]),Nom.impute=cbind(Nom.impute,row[which(miss.type=="nom")],col[which(miss.type=="nom")]),Ord.impute=cbind(round(Ord.impute),row[which(miss.type=="ord")],col[which(miss.type=="ord")]),miss.type=miss.type)
  Imputability.value.missing.mean.max.exp = sapply(1:Missing,function(x) imputability.mean.exp[row[x],col[x]])
  ## use the 25% quantile as cutoff of imputability
  cutoff.mean.exp = quantile(Imputability.value.missing.mean.max.exp)[2]
  select.mean.max.exp = which(Imputability.value.missing.mean.max.exp>cutoff.mean.exp)
  Prop.imputable.exp = list(unimputable=table(miss.type[-select.mean.max.exp]))
  Unimputable = which(Imputability.value.missing.mean.max.exp<cutoff.mean.exp)
  row.unimp = row[Unimputable]
  col.unimp = col[Unimputable]
  miss.type.unimp = miss.type[Unimputable]
  Unimputable = cbind(row.unimp,col.unimp,miss.type.unimp)
  return(list("Imputed.Data"=Data.Impute,"Methods"=Optimal.Method.out,"Unimputable Element"=Unimputable))
}

